
package com.smk;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/Sample")
public class Sample extends HttpServlet {
    private static final String URL = "jdbc:mysql://localhost:3306/pesticide_management";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
                if ("add".equals(action)) {
                    addPesticide(request, con);
                } else if ("update".equals(action)) {
                    updatePesticide(request, con);
                } else if ("delete".equals(action)) {
                    deletePesticide(request, con);
                }
                displayPesticides(con, out);
            }
        } catch (ClassNotFoundException e) {
            out.write("<p>Error: MySQL JDBC Driver not found.</p>");
            e.printStackTrace(out);
        } catch (SQLException e) {
            out.write("<p>Error: Could not connect to the database or execute query.</p>");
            e.printStackTrace(out);
        }
    }

    private void addPesticide(HttpServletRequest request, Connection con) throws SQLException {
        String name = request.getParameter("name");
        String type = request.getParameter("type");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        String sql = "INSERT INTO pesticideservlet(name, type, quantity) VALUES (?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, type);
            ps.setInt(3, quantity);
            ps.executeUpdate();
        }
    }

    private void updatePesticide(HttpServletRequest request, Connection con) throws SQLException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String type = request.getParameter("type");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        String sql = "UPDATE pesticideservlet SET name=?, type=?, quantity=? WHERE id=?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, type);
            ps.setInt(3, quantity);
            ps.setInt(4, id);
            ps.executeUpdate();
        }
    }

    private void deletePesticide(HttpServletRequest request, Connection con) throws SQLException {
        int id = Integer.parseInt(request.getParameter("id"));
        String sql = "DELETE FROM pesticideservlet WHERE id=?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    private void displayPesticides(Connection con, PrintWriter out) throws SQLException {
        String sql = "SELECT * FROM pesticideservlet";
        try (Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            out.write("<html><body>");
            out.write("<h2>Available Pesticides</h2>");
            out.write("<table border='1'><tr><th>ID</th><th>Name</th><th>Type</th><th>Quantity</th><th>Actions</th></tr>");
            while (rs.next()) {
                int id = rs.getInt("id");
                out.write("<tr>");
                out.write("<td>" + id + "</td>");
                out.write("<td>" + rs.getString("name") + "</td>");
                out.write("<td>" + rs.getString("type") + "</td>");
                out.write("<td>" + rs.getInt("quantity") + "</td>");
                out.write("<td>"
                    + "<button onclick='updatePesticide(" + id + ")'>Update</button>"
                    + "<button onclick='deletePesticide(" + id + ")'>Delete</button>"
                    + "</td>");
                out.write("</tr>");
            }
            out.write("</table>");
            out.write("</body></html>");
        }
    }
}
